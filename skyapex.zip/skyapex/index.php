<?php
require_once 'dompdf/autoload.inc.php';

use Dompdf\Dompdf;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $father_name = htmlspecialchars($_POST['father_name']);
    $property_size = htmlspecialchars($_POST['property_size']);
    $sale_amount = htmlspecialchars($_POST['sale_amount']);
    $date = htmlspecialchars($_POST['date']);

    $html = "
        <style>
            body {
                font-family: DejaVu Sans, sans-serif;
                padding: 30px;
                line-height: 1.6;
            }
            .deed-title {
                text-align: center;
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 30px;
                border-bottom: 2px solid #333;
                padding-bottom: 10px;
            }
            .section {
                margin-bottom: 20px;
            }
            .label {
                font-weight: bold;
                color: #444;
            }
            .value {
                color: #222;
            }
            .box {
                border: 1px solid #ccc;
                border-radius: 6px;
                padding: 20px;
                background: #f9f9f9;
            }
        </style>

        <div class='deed-title'>SALE DEED DOCUMENT</div>
        <div class='box'>
            <div class='section'>
                This Sale Deed is made on <span class='value'><strong>$date</strong></span> between 
                <span class='value'><strong>$name</strong></span>, S/o 
                <span class='value'><strong>$father_name</strong></span>.
            </div>
            <div class='section'>
                The mentioned property has a size of <span class='value'><strong>$property_size sq.ft.</strong></span> 
                and has been sold for a total amount of 
                <span class='value'><strong>₹$sale_amount</strong></span>.
            </div>
            <div class='section'>
                Both parties agree to the terms and acknowledge the sale as per the conditions of this deed.
            </div>
            <div class='section' style='margin-top:40px;'>
                <table width='100%'>
                    <tr>
                        <td><strong>Seller Signature:</strong> __________________</td>
                        <td align='right'><strong>Buyer Signature:</strong> __________________</td>
                    </tr>
                </table>
            </div>
        </div>
    ";

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4');
    $dompdf->render();
    $dompdf->stream("sale_deed.pdf", ["Attachment" => 1]);
    exit;
}
?>

<!-- HTML form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sale Deed Generator</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f5f7fa;
            display: flex;
            justify-content: center;
            padding-top: 40px;
        }

        .container {
            background: white;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 4px 14px rgba(0,0,0,0.1);
            max-width: 600px;
            width: 100%;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
            color: #34495e;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        button {
            margin-top: 25px;
            width: 100%;
            padding: 12px;
            font-size: 16px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #1c5980;
        }

        .error {
            color: red;
            font-size: 13px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Generate Sale Deed PDF</h2>
        <form method="POST" onsubmit="return validateForm()">
            <label>Full Name</label>
            <input type="text" name="name" id="name" required>

            <label>Father's Name</label>
            <input type="text" name="father_name" id="father_name" required>

            <label>Property Size (sq.ft)</label>
            <input type="text" name="property_size" id="property_size" required>

            <label>Sale Amount (₹)</label>
            <input type="text" name="sale_amount" id="sale_amount" required>

            <label>Date</label>
            <input type="date" name="date" id="date" required onclick="this.showPicker()">

            <div class="error" id="error-message"></div>

            <button type="submit">Generate PDF</button>
        </form>
    </div>

    <script>
        function validateForm() {
            const name = document.getElementById("name").value.trim();
            const father = document.getElementById("father_name").value.trim();
            const propertySize = document.getElementById("property_size").value.trim();
            const saleAmount = document.getElementById("sale_amount").value.trim();
            const date = document.getElementById("date").value.trim();
            const errorBox = document.getElementById("error-message");

            // reset error
            errorBox.textContent = "";

            if (!name.match(/^[A-Za-z ]+$/)) {
                errorBox.textContent = "Full Name should contain only letters and spaces.";
                return false;
            }

            if (!father.match(/^[A-Za-z ]+$/)) {
                errorBox.textContent = "Father's Name should contain only letters and spaces.";
                return false;
            }

            if (isNaN(propertySize) || Number(propertySize) <= 0) {
                errorBox.textContent = "Property Size must be a valid positive number.";
                return false;
            }

            if (isNaN(saleAmount) || Number(saleAmount) <= 0) {
                errorBox.textContent = "Sale Amount must be a valid positive number.";
                return false;
            }

            if (!date) {
                errorBox.textContent = "Please select a valid date.";
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
